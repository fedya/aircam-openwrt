const char CCACHE_VERSION[] = "3.1.3";
